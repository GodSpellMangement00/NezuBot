const Command = require("../../abstract/command");

module.exports = class AntiNuke extends Command {
  constructor(...args) {
    super(...args, {
      name: "antinuke",
      aliases: ["antiwizz"],
      description: "Protects your server from raiders/nukers",
      usage: ["antinuke <enable/disable>"],
      category: "Antinuke",
      userPerms: ["Administrator"],
      botPerms: ["EmbedLinks", "ViewChannel", "SendMessages", "Administrator"],
      cooldown: 5,
      options: [
        {
          type: 1,
          name: "enable",
          description: "Enable Antinuke",
        },
        {
          type: 1,
          name: "disable",
          description: "Disable Antinuke",
        },
      ],
    });
  }

  // defaults
  async _getAntiNukeData(guildId) {
    let data = await this.client.database.antiNukeData.get(guildId);
    if (!data || typeof data !== "object") data = {};
    if (typeof data.enabled !== "boolean") data.enabled = false;
    if (!Array.isArray(data.whitelistusers)) data.whitelistusers = [];
    if (!data.punishAction) data.punishAction = "ban";
    return data;
  }

  _statusEmbed(guild, antiNukeData) {
    const enabled = antiNukeData.enabled ? "Yes" : "No";
    const whitelist =
      antiNukeData.whitelistusers.length > 0
        ? antiNukeData.whitelistusers.map((x) => `<@${x}>`).join(", ")
        : "None";

    return this.client.util
      .embed()
      .setTitle("Anti Nuke")
      .setDescription(
        `**Enabled:** ${enabled}\n` + `**Whitelisted Users:** ${whitelist}`
      )
      .setColor(this.client.PrimaryColor)
      .setTimestamp();
  }

  // MESSAGE COMMAND
  async run({ message, args }) {
    const guild = message.guild;
    let antiNukeData = await this._getAntiNukeData(guild.id);

    const oscheck = this.client.util.checkOwner(message.author.id);
    if (!oscheck && message.author.id !== guild.ownerId) {
      return message.reply({
        content: "Only the **server owner** can use this command.",
      });
    }

    if (!args[0]) {
      return message.channel.send({
        embeds: [this._statusEmbed(guild, antiNukeData)],
      });
    }

    const sub = args[0].toLowerCase();

    // ENABLE
    if (sub === "enable") {
      if (antiNukeData.enabled) {
        return message.channel.send({
          embeds: [
            this.client.util
              .embed()
              .setTitle("Anti Nuke")
              .setDescription(
                `${this.client.config.Client.emoji.tick} | Antinuke is already **enabled**.`
              )
              .setColor(this.client.PrimaryColor)
              .setTimestamp(),
          ],
        });
      }

      if (!oscheck && guild.memberCount < 20) {
        return message.channel.send({
          embeds: [
            this.client.util
              .embed()
              .setTitle("Anti Nuke")
              .setDescription(
                "Antinuke can only be enabled on servers with **20+ members**."
              )
              .setColor(this.client.PrimaryColor)
              .setTimestamp(),
          ],
        });
      }

      antiNukeData.enabled = true;
      await this.client.database.antiNukeData.post(guild.id, antiNukeData);

      return message.channel.send({
        embeds: [
          this.client.util
            .embed()
            .setTitle("Anti Nuke")
            .setDescription(
              `${this.client.config.Client.emoji.tick} | Antinuke has been **enabled**.`
            )
            .setColor(this.client.PrimaryColor)
            .setTimestamp(),
        ],
      });
    }

    // DISABLE
    if (sub === "disable") {
      if (!antiNukeData.enabled) {
        return message.channel.send({
          embeds: [
            this.client.util
              .embed()
              .setTitle("Anti Nuke")
              .setDescription(
                `${this.client.config.Client.emoji.tick} | Antinuke is already **disabled**.`
              )
              .setColor(this.client.PrimaryColor)
              .setTimestamp(),
          ],
        });
      }

      antiNukeData.enabled = false;
      await this.client.database.antiNukeData.post(guild.id, antiNukeData);

      return message.channel.send({
        embeds: [
          this.client.util
            .embed()
            .setTitle("Anti Nuke")
            .setDescription(
              `${this.client.config.Client.emoji.tick} | Antinuke has been **disabled**.`
            )
            .setColor(this.client.PrimaryColor)
            .setTimestamp(),
        ],
      });
    }
  }

  // SLASH COMMAND
  async exec({ interaction }) {
    const guild = interaction.guild;
    let antiNukeData = await this._getAntiNukeData(guild.id);

    const oscheck = this.client.util.checkOwner(interaction.user.id);
    if (!oscheck && interaction.user.id !== guild.ownerId) {
      return interaction.reply({
        content: "Only the **server owner** can use this command.",
        ephemeral: true,
      });
    }

    const sub = interaction.options.getSubcommand(false);

    if (!sub) {
      return interaction.reply({
        embeds: [this._statusEmbed(guild, antiNukeData)],
        ephemeral: true,
      });
    }

    // ENABLE
    if (sub === "enable") {
      if (antiNukeData.enabled) {
        return interaction.reply({
          embeds: [
            this.client.util
              .embed()
              .setTitle("Anti Nuke")
              .setDescription(
                `${this.client.config.Client.emoji.tick} | Antinuke is already **enabled**.`
              )
              .setColor(this.client.PrimaryColor)
              .setTimestamp(),
          ],
          ephemeral: true,
        });
      }

      if (!oscheck && guild.memberCount < 25) {
        return interaction.reply({
          embeds: [
            this.client.util
              .embed()
              .setTitle("Anti Nuke")
              .setDescription(
                "Antinuke can only be enabled on servers with **25+ members**."
              )
              .setColor(this.client.PrimaryColor)
              .setTimestamp(),
          ],
          ephemeral: true,
        });
      }

      antiNukeData.enabled = true;
      await this.client.database.antiNukeData.post(guild.id, antiNukeData);

      return interaction.reply({
        embeds: [
          this.client.util
            .embed()
            .setTitle("Anti Nuke")
            .setDescription(
              `${this.client.config.Client.emoji.tick} | Antinuke has been **enabled** successfully.`
            )
            .setColor(this.client.PrimaryColor)
            .setTimestamp(),
        ],
        ephemeral: true,
      });
    }

    // DISABLE
    if (sub === "disable") {
      if (!antiNukeData.enabled) {
        return interaction.reply({
          embeds: [
            this.client.util
              .embed()
              .setTitle("Anti Nuke")
              .setDescription(
                `${this.client.config.Client.emoji.tick} | Antinuke is already **disabled**.`
              )
              .setColor(this.client.PrimaryColor)
              .setTimestamp(),
          ],
          ephemeral: true,
        });
      }

      antiNukeData.enabled = false;
      await this.client.database.antiNukeData.post(guild.id, antiNukeData);

      return interaction.reply({
        embeds: [
          this.client.util
            .embed()
            .setTitle("Anti Nuke")
            .setDescription(
              `${this.client.config.Client.emoji.tick} | Antinuke has been **disabled**.`
            )
            .setColor(this.client.PrimaryColor)
            .setTimestamp(),
        ],
        ephemeral: true,
      });
    }
  }
};
