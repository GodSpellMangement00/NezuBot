    const Command = require("../../abstract/command");
    const {
      StringSelectMenuBuilder,
      ActionRowBuilder,
      ContainerBuilder,
      TextDisplayBuilder,
      SeparatorBuilder,
      MessageFlags,
      MediaGalleryBuilder,
      MediaGalleryItemBuilder,
      SeparatorSpacingSize,
    } = require("discord.js");

    module.exports = class HelpCommand extends Command {
      constructor(...args) {
        super(...args, {
          name: "help",
          aliases: ["h", "commands"],
          description: "Get information about all commands.",
          usage: ["help", "help [command]"],
          category: "Utilities",
          examples: ["help"],
          userPerms: ["SendMessages"],
          guildOnly: true,
          botPerms: ["EmbedLinks", "ViewChannel", "SendMessages"],
          cooldown: 5,
          slash: true,
        });

        // Categories object - WITHOUT prefix (we'll add it dynamically)
        this.categories = {
          Antinuke: [
            "antinuke enable",
            "antinuke disable",
            "whitelist",
            "vanityguard",
          ],
          Fun: [
            "acceptmarry",
            "akinator",
            "blush",
            "bonk",
            "cry",
            "cuddle",
            "dance",
            "dare",
            "declinemarry",
            "divorce",
            "emojify",
            "fact",
            "feed",
            "gayrate",
            "gecg",
            "kill",
            "kiss",
            "lick",
            "marry",
            "matchpairs",
            "megumin",
            "meow",
            "minesweeper",
            "nom",
            "paranoia",
            "pat",
            "poke",
            "reaction",
            "rps",
            "ship",
            "simprate",
            "slap",
            "slot",
            "tictactoe",
            "truth",
            "wallpaper",
            "whatyourather",
            "wink",
            "woof",
          ],
          Giveaways: ["delete", "gend", "greroll", "snowflake", "gstart"],
        
          Moderation: [
            "automoderation",
            "ban",
            "clear",
            "hide",
            "kick",
            "lock",
            "nuke",
            "punishment",
            "role",
            "slowmode",
            "timeout",
            "unban",
            "unhide",
            "unlock",
            "unmute",
          ],
          Utilities: [
            "afk",
            "audit",
            "avatar",
            "banner",
            "blacklist",
            "botinfo",
            "embed",
            "intro",
            "invite",
            "inviteinfo",
            "managerrole",
            "membercount",
            "ping",
            "prefix",
            "premium",
            "presenceroles",
            "profile",
            "record",
            "roleicon",
            "rolesetup",
            "serverinfo",
            "setup",
            "starboard",
            "statusrole",
            "steal",
            "stickynick",
            "support",
            "translate",
            "userinfo",
            "variables",
            "vcrole",
            "youtube",
            "todo",
            "ce",
            "birthday",
          ],
          Welcome: ["autorole", "greet", "welcome"],
          Verfication: ["verification", "reactionrole"],
          Warn: [
            "warn @user [reason]",
            "warnpunish <warnCount> <action> [time in hours]",
            "clearcase @user",
            "casedelete @user",
            "case @user",
            "caseedit @user [reason]",
          ],
        };

        // Category emojis
        this.categoryEmojis = {
          Antinuke: "<:se_antinuke:1415732025238880427>",
          Fun: "<:se_fun:1415650890144022630>",
          Giveaways: "<:se_gift:1415653417509978213>",
          
          Moderation: "<:se_mod:1415650508835655792>",
          Utilities: "<:se_utility:1415651001335021661>",
          Welcome: "<:se_welcome:1415650367181553694>",
          Verfication: "<:Verify:1418271803939487776>",
          Warn: "<:modbw:1415654964088274965>",
        };

        // Category descriptions
        this.categoryDescriptions = {
          Antinuke: "Protect your server from raids and suspicious activity.",
          Fun: "Commands for entertainment and games.",
          Giveaways: "Create and manage server giveaways.",
        
          Moderation: "Tools for server moderation and management.",
          Utilities: "General purpose commands and useful tools.",
          Welcome: "Setup welcome/goodbye messages and autoroles.",
          Verfication: "Setup advanced verification system fast!",
          Warn: "Manage warnings and cases for server moderation.",
        };
      }

      async run({ message, args }) {
        await this.showHelp(message, args, false);
      }

      async exec({ interaction }) {
        await this.showHelp(interaction, [], true);
      }

      async showHelp(ctx, args, isSlash) {
        const user = isSlash ? ctx.user : ctx.author;
        const guild = ctx.guild;
        guild.config = await this.client.database.guildData.get(guild.id);

        const totalCommands = this.client.commands.size;
        const slashCommands = this.client.slashCommands?.size || 0;

        const mainContainer = this.createMainHelpContainer(
          guild.config.prefix,
          totalCommands,
          slashCommands
        );

        const helpmenu = await (isSlash
          ? ctx.reply({
              components: [mainContainer],
              flags: MessageFlags.IsComponentsV2,
              fetchReply: true,
              ephemeral: true,
            })
          : ctx.reply({
              components: [mainContainer],
              flags: MessageFlags.IsComponentsV2,
              fetchReply: true,
            }));

        const collector = helpmenu.createMessageComponentCollector({
          time: 600000,
          filter: (i) => i.user.id === user.id,
        });

        collector.on("collect", async (interaction) => {
          if (interaction.customId === "help_menu") {
            const selectedCategory = interaction.values[0];
            const categoryContainer = this.createCategoryContainer(
              selectedCategory,
              guild.config.prefix,
              totalCommands,
              slashCommands
            );

            await interaction.update({
              components: [categoryContainer],
              flags: MessageFlags.IsComponentsV2,
            });
          }
        });

        collector.on("end", async () => {
          try {
            // Optionally disable components after collector ends
            const disabledContainer = this.createMainHelpContainer(
              guild.config.prefix,
              totalCommands,
              slashCommands,
              true
            );
            await helpmenu.edit({
              components: [disabledContainer],
              flags: MessageFlags.IsComponentsV2,
            });
          } catch {}
        });
      }

      createMainHelpContainer(
        prefix,
        totalCommands,
        slashCommands,
        disabled = false
      ) {
        const container = new ContainerBuilder();

        // Main help text
        container.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `# <:se_utility:1415651001335021661> Synapse Energy Help Menu\n\n` +
              `Hello, I'm Synapse Energy - a powerful multi-purpose Discord bot with advanced security features.\n\n` +
              `**<:se_mod:1415650508835655792> Get Started**\n` +
              `<:arrow:1415657127426523257>Current Prefix: \`${prefix}\`\n` +
              `<:arrow:1415657127426523257> Change Prefix: \`${prefix}prefix <new prefix>\`\n` +
              `<:arrow:1415657127426523257> Total Commands: **${totalCommands}**\n` +
              `<:arrow:1415657127426523257> Slash Commands: **83**\n` +
              `**Also Prefix in help menu will be automatically adjusted to your server prefix!**`
          )
        );

        // Divider separator
        container.addSeparatorComponents(
          new SeparatorBuilder()
            .setDivider(true)
            .setSpacing(SeparatorSpacingSize.Small)
        );

        // Add select menu inside container
        const selectMenu = new StringSelectMenuBuilder()
          .setCustomId("help_menu")
          .setPlaceholder("Select a category")
          .setMinValues(1)
          .setMaxValues(1)
          .setDisabled(disabled)
          .addOptions([
            {
              label: "Home",
              value: "home",
              emoji: "🏠",
              description: "Return to main help page",
            },
            ...Object.keys(this.categories).map((cat) => ({
              label: cat,
              value: cat.toLowerCase(),
              emoji: this.categoryEmojis[cat] || "📦",
              description: this.categoryDescriptions[cat] || "View commands",
            })),
          ]);

        container.addActionRowComponents(
          new ActionRowBuilder().addComponents(selectMenu)
        );

        return container;
      }

      createCategoryContainer(
        category,
        prefix,
        totalCommands,
        slashCommands,
        disabled = false
      ) {
        if (category === "home") {
          return this.createMainHelpContainer(
            prefix,
            totalCommands,
            slashCommands,
            disabled
          );
        }

        const container = new ContainerBuilder();

        // Find the matching category (case-insensitive)
        const categoryKey = Object.keys(this.categories).find(
          (key) => key.toLowerCase() === category.toLowerCase()
        );

        const commands = this.categories[categoryKey] || [];
        // Add the prefix dynamically to each command
        const commandList = commands.map((cmd) => `\`${prefix}${cmd}\``).join(", ");

        // Category title
        container.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `# ${this.categoryEmojis[categoryKey]} ${categoryKey} Commands\n\n` +
              `${this.categoryDescriptions[categoryKey] || ""}`
          )
        );

        // Separator
        container.addSeparatorComponents(new SeparatorBuilder());

        // Commands list
        container.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `**Available Commands [${commands.length}]**\n\n` +
              (commandList || "No commands available.")
          )
        );

        // Separator
        container.addSeparatorComponents(new SeparatorBuilder());

        // Footer info
        container.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `Use \`${prefix}help <command>\` for detailed information about a specific command.`
          )
        );

        // Divider separator
        container.addSeparatorComponents(
          new SeparatorBuilder()
            .setDivider(true)
            .setSpacing(SeparatorSpacingSize.Small)
        );

        // Add select menu inside container
        const selectMenu = new StringSelectMenuBuilder()
          .setCustomId("help_menu")
          .setPlaceholder("Select a category")
          .setMinValues(1)
          .setMaxValues(1)
          .setDisabled(disabled)
          .addOptions([
            {
              label: "Home",
              value: "home",
              emoji: "🏠",
              description: "Return to main help page",
            },
            ...Object.keys(this.categories).map((cat) => ({
              label: cat,
              value: cat.toLowerCase(),
              emoji: this.categoryEmojis[cat] || "📦",
              description: this.categoryDescriptions[cat] || "View commands",
            })),
          ]);

        container.addActionRowComponents(
          new ActionRowBuilder().addComponents(selectMenu)
        );

        return container;
      }
    };
