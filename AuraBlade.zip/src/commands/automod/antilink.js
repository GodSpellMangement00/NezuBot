const Command = require("../../abstract/command");
const { EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = class AntiLink extends Command {
  constructor(...args) {
    super(...args, {
      name: "antilink",
      aliases: ["linkblock"],
      description:
        "Create an Anti-Link AutoMod rule with a custom block message",
      usage: ["antilink enable"],
      category: "Moderation",
      userPerms: ["Administrator"],
      botPerms: ["ManageGuild"],
      guildOnly: true,
    });
  }

  async run({ message, args }) {
    if (
      !message.member.permissions.has(PermissionsBitField.Flags.Administrator)
    ) {
      return message.reply(
        "❌ You need **Administrator** permissions to use this command."
      );
    }

    try {
      await message.guild.autoModerationRules.create({
        name: "Anti-Link",
        creatorId: message.author.id,
        enabled: true,
        eventType: 1, // MESSAGE_SEND
        triggerType: 1, // KEYWORD
        triggerMetadata: {
          keywordFilter: ["discord.gg", "http://", "https://", "www."],
        },
        actions: [
          {
            type: 1, // BLOCK_MESSAGE
            metadata: {
              customMessage:
                "🚫 Links are not allowed here! Please avoid posting links.",
            },
          },
        ],
      });

      const embed = new EmbedBuilder()
        .setColor("#5FFD0A")
        .setDescription("✅ **Anti-Link** rule created successfully!");
      return message.channel.send({ embeds: [embed] });
    } catch (err) {
      console.error(err);
      return message.channel.send(
        "❌ Failed to create **Anti-Link** rule. Check my permissions and try again."
      );
    }
  }

  async exec({ interaction }) {
    if (
      !interaction.member.permissions.has(
        PermissionsBitField.Flags.Administrator
      )
    ) {
      return interaction.reply({
        content:
          "❌ You need **Administrator** permissions to use this command.",
        ephemeral: true,
      });
    }

    try {
      await interaction.guild.autoModerationRules.create({
        name: "Anti-Link",
        creatorId: interaction.user.id,
        enabled: true,
        eventType: 1,
        triggerType: 1,
        triggerMetadata: {
          keywordFilter: ["discord.gg", "http://", "https://", "www."],
        },
        actions: [
          {
            type: 1,
            metadata: {
              customMessage:
                "🚫 Links are not allowed here! Please avoid posting links.",
            },
          },
        ],
      });

      const embed = new EmbedBuilder()
        .setColor("#5FFD0A")
        .setDescription("✅ **Anti-Link** rule created successfully!");
      return interaction.reply({ embeds: [embed], ephemeral: true });
    } catch (err) {
      console.error(err);
      return interaction.reply({
        content:
          "❌ Failed to create **Anti-Link** rule. Check my permissions and try again.",
        ephemeral: true,
      });
    }
  }
};
