const Command = require("../../abstract/command");
const { EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = class SetupAutoMod extends Command {
  constructor(...args) {
    super(...args, {
      name: "setupautomod",
      aliases: ["automodsetup", "amsetup"],
      description:
        "Setup AutoMod rules for your server with custom block messages",
      usage: ["setupautomod"],
      category: "Moderation",
      userPerms: ["Administrator"],
      botPerms: ["ManageGuild"],
      guildOnly: true,
    });
  }

  async run({ message }) {
    if (
      !message.member.permissions.has(PermissionsBitField.Flags.Administrator)
    ) {
      return message.reply(
        "❌ You need **Administrator** permissions to use this command."
      );
    }

    const guild = message.guild;
    const creatorId = message.author.id;

    const rules = [
      {
        name: "Anti-Link",
        triggerType: 1, // KEYWORD
        triggerMetadata: {
          keywordFilter: ["discord.gg", "http://", "https://", "www."],
        },
        actionMessage:
          "🚫 Links are not allowed here! Please avoid posting links.",
      },
      {
        name: "Anti-Mention",
        triggerType: 1,
        triggerMetadata: { keywordFilter: ["@everyone", "@here"] },
        actionMessage: "⚠️ Excessive mentions are not allowed!",
      },
      {
        name: "Blacklist Words",
        triggerType: 1,
        triggerMetadata: {
          keywordFilter: ["badword1", "badword2", "badword3"],
        },
        actionMessage: "❌ That word is not allowed!",
      },
    ];

    for (const ruleData of rules) {
      try {
        await guild.autoModerationRules.create({
          name: ruleData.name,
          creatorId,
          enabled: true,
          eventType: 1, // MESSAGE_SEND
          triggerType: ruleData.triggerType,
          triggerMetadata: ruleData.triggerMetadata,
          actions: [
            {
              type: 1, // BLOCK_MESSAGE
              metadata: {
                customMessage: ruleData.actionMessage,
              },
            },
          ],
        });

        const embed = new EmbedBuilder()
          .setColor("#5FFD0A")
          .setDescription(
            `✅ **${ruleData.name}** rule created successfully with a custom block message!`
          );

        await message.channel.send({ embeds: [embed] });
      } catch (err) {
        console.error(err);
        const embed = new EmbedBuilder()
          .setColor("#FF0000")
          .setDescription(
            `❌ Failed to create **${ruleData.name}**. Check my permissions and try again.`
          );
        await message.channel.send({ embeds: [embed] });
      }
    }
  }

  async exec({ interaction }) {
    if (
      !interaction.member.permissions.has(
        PermissionsBitField.Flags.Administrator
      )
    ) {
      return interaction.reply({
        content:
          "❌ You need **Administrator** permissions to use this command.",
        ephemeral: true,
      });
    }

    const guild = interaction.guild;
    const creatorId = interaction.user.id;

    const rules = [
      {
        name: "Anti-Link",
        triggerType: 1,
        triggerMetadata: {
          keywordFilter: ["discord.gg", "http://", "https://", "www."],
        },
        actionMessage:
          "🚫 Links are not allowed here! Please avoid posting links.",
      },
      {
        name: "Anti-Mention",
        triggerType: 1,
        triggerMetadata: { keywordFilter: ["@everyone", "@here"] },
        actionMessage: "⚠️ Excessive mentions are not allowed!",
      },
      {
        name: "Blacklist Words",
        triggerType: 1,
        triggerMetadata: {
          keywordFilter: ["badword1", "badword2", "badword3"],
        },
        actionMessage: "❌ That word is not allowed!",
      },
    ];

    for (const ruleData of rules) {
      try {
        await guild.autoModerationRules.create({
          name: ruleData.name,
          creatorId,
          enabled: true,
          eventType: 1,
          triggerType: ruleData.triggerType,
          triggerMetadata: ruleData.triggerMetadata,
          actions: [
            {
              type: 1,
              metadata: {
                customMessage: ruleData.actionMessage,
              },
            },
          ],
        });

        const embed = new EmbedBuilder()
          .setColor("#5FFD0A")
          .setDescription(
            `✅ **${ruleData.name}** rule created successfully with a custom block message!`
          );

        await interaction.followUp({ embeds: [embed], ephemeral: true });
      } catch (err) {
        console.error(err);
        const embed = new EmbedBuilder()
          .setColor("#FF0000")
          .setDescription(
            `❌ Failed to create **${ruleData.name}**. Check my permissions and try again.`
          );
        await interaction.followUp({ embeds: [embed], ephemeral: true });
      }
    }
  }
};
