const Command = require("../../abstract/command");
const { EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = class ResetAutoMod extends Command {
  constructor(...args) {
    super(...args, {
      name: "resetautomod",
      aliases: ["automodreset", "amreset"],
      description: "Remove all AutoMod rules from your server",
      usage: ["resetautomod"],
      category: "Moderation",
      userPerms: ["Administrator"],
      botPerms: ["ManageGuild"],
      guildOnly: true,
    });
  }

  async run({ message }) {
    if (
      !message.member.permissions.has(PermissionsBitField.Flags.Administrator)
    ) {
      return message.reply(
        "❌ You need **Administrator** permissions to use this command."
      );
    }

    try {
      const rules = await message.guild.autoModerationRules.fetch();
      for (const rule of rules.values()) {
        await rule.delete(`Reset by ${message.author.tag}`);
      }

      const embed = new EmbedBuilder()
        .setColor("#5FFD0A")
        .setDescription(
          "✅ All AutoMod rules have been successfully **reset**!"
        );
      return message.channel.send({ embeds: [embed] });
    } catch (err) {
      console.error(err);
      return message.channel.send(
        "❌ Failed to reset AutoMod rules. Check my permissions and try again."
      );
    }
  }

  async exec({ interaction }) {
    if (
      !interaction.member.permissions.has(
        PermissionsBitField.Flags.Administrator
      )
    ) {
      return interaction.reply({
        content:
          "❌ You need **Administrator** permissions to use this command.",
        ephemeral: true,
      });
    }

    try {
      const rules = await interaction.guild.autoModerationRules.fetch();
      for (const rule of rules.values()) {
        await rule.delete(`Reset by ${interaction.user.tag}`);
      }

      const embed = new EmbedBuilder()
        .setColor("#5FFD0A")
        .setDescription(
          "✅ All AutoMod rules have been successfully **reset**!"
        );
      return interaction.reply({ embeds: [embed], ephemeral: true });
    } catch (err) {
      console.error(err);
      return interaction.reply({
        content:
          "❌ Failed to reset AutoMod rules. Check my permissions and try again.",
        ephemeral: true,
      });
    }
  }
};
